import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../pages/UserPage.css';
import { useTable } from 'react-table';
import { PencilIcon, TrashIcon, CheckIcon, XIcon } from '@heroicons/react/outline';

function UserPage() {
  const [records, setRecords] = useState([]);
  const columns = React.useMemo(() => {
    return [
      {
        Header: "Id",
        accessor: "id",
      },
      {
        Header: "Description",
        accessor: "description",
      },
      {
        Header: "Address",
        accessor: "address",
      },
      {
        Header: "MaxHourlyEnergyConsumption",
        accessor: "maxHourlyEnergyConsumption",
      },
      {
        Header: "User id",
        accessor: (row) => row.user_id?.id,
      },
    ];
  }, []);

  useEffect(() => {
    axios.get('http://localhost:8081/device',
    {headers: { 
      'Content-Type' : 'application/json',
      'Authorization': 'Bearer ' + localStorage.getItem("tokenAuthentication"),
  }})
      .then(response => {
        setRecords(response.data);
        console.log(response.data);
      })
      .catch(err => {
        console.log(err);
      });
  }, []);

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
  } = useTable({ columns, data: records });

  const handleClick = () => {
    const saveBtn = document.getElementById("saveButton");
    const cancelBtn = document.getElementById("cancelButton");
    saveBtn.style.visibility = 'visible';
    cancelBtn.style.visibility = 'visible';
  };

  return (
    <div className="fetchData">
      <h1 className="title">Devices Table</h1>
  
      {records.length === 0 ? (
        <p>No records found.</p>
      ) : (
        <div className="container">
          <table {...getTableProps()}>
            <thead>
              {headerGroups.map((headerGroup) => (
                <tr {...headerGroup.getHeaderGroupProps()}>
                  {headerGroup.headers.map((column) => (
                    <th {...column.getHeaderProps()}>{column.render("Header")}</th>
                  ))}
                  <th>Edit/Delete</th>
                </tr>
              ))}
            </thead>
            <tbody {...getTableBodyProps()}>
              {rows.map((row) => {
                prepareRow(row);
                return (
                  <tr {...row.getRowProps()}>
                    {row.cells.map((cell) => (
                      <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                    ))}
                    <td>
                      <button className="editButton" id="editBtn" onClick={handleClick}>
                        <PencilIcon className="w-10 h-10" />
                      </button>
                      <button className="saveBtn" id="saveButton" style={{ visibility: "hidden" }}>
                        <CheckIcon className="w-10 h-10" />
                      </button>
                      <button className="cancelBtn" id="cancelButton" style={{ visibility: "hidden" }}>
                        <XIcon className="w-10 h-10" />
                      </button>
                      <button className="deleteButton" id="deleteBtn">
                        <TrashIcon className="w-10 h-10" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
  
      {/* <div className='inputs'>
        <div>
          <input type="text" placeholder='Description' className='description'></input>
          <input type="text" placeholder='Address' className='address'></input>
          <input type="text" placeholder='EnergyConsumption' className='maxHourlyEnergyConsumption'></input>
          <input type="text" placeholder='User id' className='userId'></input>
          <button className='addDeviceBtn'>Add device</button>
        </div>
      </div> */}
    </div>
  );
}

export default UserPage;

import React from 'react'
import '../pages/AdminPage.css';

function AdminPage(){
    return (
    <div className='main'>
      <div className='sub-main'>
       
            <div className='userBtn'>
              <button>Manage User Accounts</button>
              {/* <a href='/admin'>Admin</a> */}
            </div>
            <div className='deviceBtn'>
              <button>Manage Devices</button>
              {/* <a href='/admin'>Admin</a> */}
            </div>
      
      </div> 
    </div>
    )
}

export default AdminPage
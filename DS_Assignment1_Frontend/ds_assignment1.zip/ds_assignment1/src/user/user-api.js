


const fetchUsers = async () => {
    try {
      const response = await fetch('http://localhost:8080/user');
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    } catch (error) {
      throw new Error('Error fetching data: ' + error.message);
    }
  };





  
export {
    fetchUsers
};

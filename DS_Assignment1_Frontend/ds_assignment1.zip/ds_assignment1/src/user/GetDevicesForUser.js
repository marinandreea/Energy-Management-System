import React, { useEffect, useState } from 'react';
import Table from '../Table';
import { useParams } from "react-router-dom";
import GetErrorPageForUser from './GetErrorPageForUser';
import { useTable, userRowSelect } from 'react-table';

function ManageUserPage() {
  const { id } = useParams();
  const [records, setRecords] = useState([]);
  const[flag, setFalg] = useState(false)
  
  
  
  // const data = React.useMemo(() => records, [records]);
  // const {
  //   getTableProps,
  //   getTableBodyProps,
  //   headerGroups,
  //   rows,
  //   prepareRow,
  //   selectedFlatRows
  // } = useTable({ columns, data }, userRowSelect);


  const columns = React.useMemo(
    () => [
      {
        Header: "Description",
        accessor: "description",
      },
      {
        Header: "Address",
        accessor: "address",
      },
      {
        Header: "MaxHourlyEnergyConsumption",
        accessor: "maxHourlyEnergyConsumption",
      },
    ],
    []
  );

  useEffect(() => {
    fetch(`http://localhost:8081/deviceByUser/${id}`,
    {headers: { 
      'Content-Type' : 'application/json',
      'Authorization': 'Bearer ' + localStorage.getItem("tokenAuthentication"),
  }})
      .then( (response) => { 
        // console.log(response)
        
          if(response.status === 404){
            setFalg(true);
          }else{
            return response.json()
          }
          //return [];
      }
        
      )
      .then((data) => {
        setRecords(data);
      })
      .catch((err) => console.log(err));
  }, [id]);

 
 // console.log(flag)
  return(
    
    <div>
    {flag ? (<GetErrorPageForUser/>) : (
        <Table records={records} columns={columns} message="Devices Table" microservice="deviceD" flag={flag}  />
    )
    }
    </div>
  )
  
}

export default ManageUserPage;





